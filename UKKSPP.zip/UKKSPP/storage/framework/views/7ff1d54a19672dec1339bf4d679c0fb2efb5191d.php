<?php $__env->startSection('breadcrumb'); ?>
   <li class="breadcrumb-item">Dashboard</li>
   <li class="breadcrumb-item active">Histori</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

   <div class="row">
      <div class="col-md-12">
      
         <div class="card">
            <div class="card-body">
               <div class="card-title">Histori Pembayaran</div>
               
                  <?php $__currentLoopData = $pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <div class="border-top">
                        <div class="float-right">
                           <i class="mdi mdi-check text-success"></i> <?php echo e($value->created_at->format('d M, Y')); ?>

                        </div>
                        <div class="mt-4 text-uppercase">
                           <?php echo e($value->siswa->nama .' - '. $value->siswa->kelas->nama_kelas); ?>

                        </div>
                           <div>SPP Bulan <b class="text-capitalize"><?php echo e($value->spp_bulan); ?></b></div>
                           <div>Nominal SPP Rp.<?php echo e($spp = $value->siswa->spp->nominal); ?></div>
                           <div>Bayar Rp.<?php echo e($bayar = $value->jumlah_bayar); ?></div>
                           <div>Tunggakan Rp.<?php echo e($spp - $bayar); ?></div>                        
                     </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                         <!-- Pagination -->
					<?php if($pembayaran->lastPage() != 1): ?>
						<div class="btn-group float-right">		
						   <a href="<?php echo e($pembayaran->previousPageUrl()); ?>" class="btn btn-success">
								<i class="mdi mdi-chevron-left"></i>
						    </a>
						    <?php for($i = 1; $i <= $pembayaran->lastPage(); $i++): ?>
								<a class="btn btn-success <?php echo e($i == $pembayaran->currentPage() ? 'active' : ''); ?>" href="<?php echo e($pembayaran->url($i)); ?>"><?php echo e($i); ?></a>
						    <?php endfor; ?>
					        <a href="<?php echo e($pembayaran->nextPageUrl()); ?>" class="btn btn-success">
								<i class="mdi mdi-chevron-right"></i>
							</a>
					   </div>
					<?php endif; ?>
					<!-- End Pagination -->
                  
                  <?php if(count($pembayaran) == 0): ?>
                      <div class="text-center">Tidak ada histori pembayaran</div>
                  <?php endif; ?>
               
            </div>
         </div>
         
      </div>
   </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pembayaran-spp\resources\views/dashboard/history-pembayaran/index.blade.php ENDPATH**/ ?>