<?php $__env->startSection('breadcrumb'); ?>
	<li class="breadcrumb-item active" aria-current="page">Home</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

   <div class="alert alert-success text-center"><b>Selamat Datang</b> di aplikasi pembayaran SPP Sekolah</div>

<div class="row">
   <div class="col-md-12">
      <div class="card">
         <div class="card-body">                  
            <div class="card-title">Histori Terbaru</div>
               <div class="comment-widgets scrollable">
                             
                              <!--  Row -->
                              <?php $__currentLoopData = $pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="d-flex flex-row comment-row">
                                    <i class="mdi mdi-account display-3"></i>
                                    <div class="comment-text active w-100">
                                    <hr>
                                    <span class="badge badge-success badge-rounded float-right"><?php echo e($history->created_at->diffforHumans()); ?></span>                                    
                                        <h6 class="font-medium"><?php echo e($history->siswa->nama); ?></h6>                                       
                                        <span class="m-b-15 d-block">
                                             <ul class="list-group list-group-flush">
                                                <li class="list-group-item">Kelas <?php echo e($history->siswa->kelas->nama_kelas); ?></li>
                                                <li class="list-group-item">Jumlah Bayar Rp.<?php echo e($history->jumlah_bayar); ?></li>
                                                <li class="list-group-item">SPP Bulan <b  class="text-capitalize text-bold"><?php echo e($history->spp_bulan); ?></b></li>                                   
                                           </ul>
                                        </span>
                                        <div class="comment-footer ">
                                            <span class="text-muted float-right"><?php echo e($history->created_at->format('M d, Y')); ?></span>                                            
                                            <span class="action-icons active">
                                                    <a href="<?php echo e(url('dashboard/pembayaran/'. $history->id .'/edit')); ?>"><i class="ti-pencil-alt"></i></a>                                                  
                                                </span>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              
                                <?php if(count($pembayaran) == 0): ?>
				  			   <div class="text-center"> Tidak ada histori!</div>
					         <?php endif; ?>
                            </div>
               
         </div>
      </div>
   </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pembayaran-spp\resources\views/dashboard/index.blade.php ENDPATH**/ ?>