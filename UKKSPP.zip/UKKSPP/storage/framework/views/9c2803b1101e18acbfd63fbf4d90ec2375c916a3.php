<?php $__env->startSection('breadcrumb'); ?>
   <li class="breadcrumb-item">Dashboard</li>
   <li class="breadcrumb-item active">Laporan</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

   <div class="row">
      <div class="col-md-12">
      
         <div class="card">
            <div class="card-body">
               <div class="card-title"> Buat Laporan</div>
               
                  <div class="alert alert-warning">Buat laporan pembayaran SPP siswa, semua data siswa akan di rekap dan di buat laporannya.</div>
                       
                  <a href="<?php echo e(url('dashboard/laporan/create')); ?>" class="btn btn-primary btn-rounded">Buat Laporan</a>
                                
            </div>
         </div>
      
      </div>
   </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pembayaran-spp\resources\views/dashboard/generate-laporan/index.blade.php ENDPATH**/ ?>